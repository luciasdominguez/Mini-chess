#pragma once
#include "math.h"

struct Vector2D
{
	double x{}, y{};
};


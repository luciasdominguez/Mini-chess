#pragma once
#include <ctime>
#include <sstream>
#include <iostream>

using namespace std;


string getDate();  // codigo de https://xtokio.github.io/blog/2017/c-obtener-fecha-actual/
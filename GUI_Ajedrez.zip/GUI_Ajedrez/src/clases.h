#pragma once 

enum class colision { vacio, amigo, enemigo };

enum ENUM_COLOR { blanca, negra };


#include "casillas.h"

//casilla::casilla(int _fila, int _columna, fichas* _ficha) {
//	fila = _fila;
//	columna = _columna;
//	ocupacion = _ficha;
//}
casilla::casilla() {
	ocupacion = nullptr;
}

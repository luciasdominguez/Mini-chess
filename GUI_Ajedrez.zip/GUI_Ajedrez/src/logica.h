#pragma once
#include <vector>
#include "GUI_partida.h"
#include "GUI_pieza.h"

//enum ENUM_ANALISIS {  = 0, NEGRAS, GRAVEDAD_N, GRAVEDAD_B };
enum ENUM_TRAYECTO { TR_torre = 0, TR_alfil = 1, TR_caballo = 2, TR_otro = -1 };

class Cl_logica
{
	GUI_partida _partida_in;
	GUI_jugada jug;
	bool jaque_mate = false;
	PIEZA_STRU pz;
	PIEZA_STRU pz_0;


	//T_tablero
	vector<vector<PIEZA_STRU>> _Tablero_actual;
	PIEZA_STRU busca_posicion_anterior(PIEZA_STRU pieza_jugada);


	//void analiza_gravedad();  // por hacer...............

	int analiza_jugada___(vector<vector<PIEZA_STRU>> Tablero_actual_, GUI_jugada& jugada_propia, GUI_jugada& jugada_gravedad, bool jugada_erronea);


public:
	Cl_logica();


	// Si la jugada es correcta:
	//	se genera la "jugada_propia" pero a�adiendo, si es el caso,
	//	el resto de piezas afectadas (por haber comido una pieza contraria, un enroque ...
	//	Tambien se devuelve en "jugada_gravedad" la lista de las piezas que se ven afectadas por la gravedad.
	// 
	// Si la "jugaga_gravedad" ha generado un jaque mate devuelve 2 para que se termine la partida
	// si no es jaque mate devuelve 1
	// Si la ultima jugada en valida al funci�n devuelve 0;
	int analiza_jugada(vector<vector<PIEZA_STRU>> Tablero_actual_, // situaci�n del tablero antes de realizar la "jugada_propia"
		GUI_jugada& jugada_propia, // jugada que se debe analizar en funci�n de la situaci�n del tablero
		// se devolver� la jugada actualizada si la logica del juego afecta a otra pieza
		GUI_jugada& jugada_gravedad, // jugada que realiza la gravedad
		bool jugada_erronea);  // solamete para test


	/////////////////////

};
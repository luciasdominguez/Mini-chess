#include "ETSIDI.h"
#include <string>
#include "GUI_Tablero.h"
using namespace ETSIDI;

class GUI_turno
{
	ENUM_JUGADOR turno = BLANCAS; //GRAVEDAD_N;
	float pos_x{}, pos_y{}; /// posici�n seg�n escala del sprite
	void calcula_Pos_turno(ENUM_JUGADOR turno);

protected:
	SpriteSequence* sprite_turno;

public:
	GUI_turno();
	void dibuja_turno(ENUM_JUGADOR turno);
};


/// ///////////////
///  jaque mate
///////////////////
class GUI_jaque_mate
{

	/// posici�n seg�n escala del sprite
	float pos_x{}, pos_y{};
	bool ver_jaque_mate;
protected:
	SpriteSequence* sprite_jaque;

public:
	GUI_jaque_mate();
	void dibuja_jaque_mate();
	void set_ver_jaque_mate(bool ver);
	bool get_ver_jaque_mate();

};
